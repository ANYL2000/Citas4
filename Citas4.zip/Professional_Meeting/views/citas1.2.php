<?php
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion



if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}else{
$usuario = $_SESSION['login_user_sys'];

if($usuario!='Administrador'){
  session_destroy();
  echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";

}

}

$tallerista_seleccionado = $_GET['tallerista'];
 $taller_seleccionado = $_GET["taller"];
 $calendario_seleccionado = $_GET['calendario'];
$hora_seleccionado = $_GET['hora'];


//print_r($taller_seleccionado);

$conexion = mysqli_connect($host, $db_username, $db_password,$db_name );
//$query =$conexion->prepare("SELECT * FROM usuarios_talleres WHERE Ingreso = '$calendario_seleccionado' AND NombreTaller = '$taller_seleccionado' AND Dia = '$dia_seleccionado' AND Turno = '$turno_seleccionado';");
$conexion->query("SET NAMES 'utf8'");
$con = connect($host, $port, $db_name, $db_username, $db_password);
$con->query("SET NAMES 'utf8'");

$validar_citas = "SELECT * FROM mostrar_cita WHERE NombreEspecialista = '$tallerista_seleccionado' AND NombreEspecialidad = '$taller_seleccionado' AND Calendario = '$calendario_seleccionado' AND Hora = '$hora_seleccionado'";

$filas_citas = mysqli_query($conexion,$validar_citas);


if(mysqli_num_rows($filas_citas)==0){
  echo "<script type='text/javascript'>
  window.location='citas1.1.php'
  </script>";
}

$sql = "SELECT * FROM pacientes_reservados WHERE NombreEspecialista='$tallerista_seleccionado' AND Calendario = '$calendario_seleccionado' AND NombreEspecialidad = '$taller_seleccionado' AND Hora = '$hora_seleccionado' ;";

$result = mysqli_query($conexion,$sql);

//$query->execute();
//$resultado =$query->fetchAll();

//echo "<script> console.log('$taller_seleccionado') </script>";

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<header>
    <title>Oasis</title>
</header>




<link rel="stylesheet" href="../assets/css/estilo_citas1.2.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php include 'header_citas.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;z-index:20;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    


<div class="fondo">

<a class="btn btn-primary talleres" id="talleres" href="citas1.1.php">Ir a Citas registradas</a>

<h1 class="titulo_taller">Cliente registrado</h1>
<div class="taller_informacion">
<p id="subtitulo"> ESPECIALISTA: <p><?php echo "$tallerista_seleccionado"?></p> </p>
<p id="subtitulo">  ESPECIALIDAD: <p><?php echo "$taller_seleccionado"?></p> </p>
<p id="subtitulo">  CALENDARIO: <p> <?php echo "$calendario_seleccionado"?></p></p>
<p id="subtitulo">  HORA: <p> <?php echo "$hora_seleccionado "?></p></p>
</div>


<table class="table-responsive">
    <thead>
<tr class="fila_principal">
    <td>Nombre</td>
    <td>Apellidos</td>
    <td>Curp</td>
   
</tr>
</thead>

<tbody>


<?php  
while($fila = mysqli_fetch_array($result)){ 

?>

<tr class="filas_secundarias" id="color_gris" >
   
    <td><?php echo $fila['Nombre']; ?></td>
    <td><?php echo $fila['Apellido']; ?></td>
    <td><?php echo $fila['Curp']; ?></td>

  <td><button type='submit' class='boton_editar' id='abrir_editar' name='abrir_editar' data-toggle='modal' data-target="#editModal<?php echo $fila['idUsuarios']; ?>">Editar</button></td>
<td><button type='submit' class='boton_borrar' data-toggle='modal' data-target="#deleteModal<?php echo $fila['idUsuarios']; ?>">Eliminar</button></td>
</tr>

</tbody>
<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Editar-->
<div class="modal fade" id="editModal<?php echo $fila['idUsuarios']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar información</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
        <!--<div class="form-group">
            <label for="recipient-name" class="col-form-label">Codigo:</label>
          
            <input type="text" class="form-control" id="recipient_codigo" name="recipient_codigo" value="<?php echo $fila["Codigo"]; ?>" required autocomplete="off">
          </div>   data-dismiss="modal"-->
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nombre:</label>
            <input type="text" class="form-control" id="recipient_id" name="recipient_id" value="<?php echo $fila["idUsuarios"]; ?>" hidden="true" autocomplete="off">
            <input type="text" class="form-control" id="recipient_nombre"  name = "recipient_nombre" value="<?php echo $fila["Nombre"]; ?>" required autocomplete="off">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Apellidos:</label>
            <input type="text" class="form-control" id="recipient_carrera" name="recipient_apellido" value="<?php echo $fila["Apellido"]; ?>" required autocomplete="off">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">CURP:</label>
            <input type="text" class="form-control" id="recipient_curp" name="recipient_curp" value="<?php echo $fila["Curp"]; ?>" required autocomplete="off">
          </div>

          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  >Cerrar</button>
        <button type="submit" class="btn btn-primary" id="btneditar" name="btneditar">Guardar cambios</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>

<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Borrar-->
<div class="modal fade" id="deleteModal<?php echo $fila['idUsuarios'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Desea eliminar a: </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="borrar_usuario.php?id=<?php echo $fila['idUsuarios'] ?>&tallerista=<?php echo $fila['NombreEspecialista'] ?>&taller=<?php echo $fila['NombreEspecialidad'] ?>&calendario=<?php echo $fila['Calendario'] ?>&hora=<?php echo $fila['Hora'] ?>" method="POST">
        <div class="form-group">
            <label for="recipient-name" class="col-form-label"><?php echo $fila["Nombre"]; echo ' ';?> <?php echo $fila["Apellido"]; ?></label>
      
          </div>
       
          <div class="modal-footer">
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-danger" id="eliminar" name="eliminar">Eliminar</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>

 <?php
//include ("modal_editar.php");
?>
<?php
//include ("modal_eliminar.php");
?>

<?php



}
?>


</table>

<!--<a href="lista_pdf.php?tallerista=<?php //echo $tallerista_seleccionado ?>&taller=<?php // echo $taller_seleccionado?>&calendario=<?php// echo $calendario_seleccionado?>&turno=<?php //echo $turno_seleccionado?>&dia=<?php //echo $dia_seleccionado?>"><button class="btn_imprimir"><i class="fa fa-print fa-2x fa-lg" ></i><p>Imprimir Resetario</p></button></a>-->

   
<?php
if(isset($_POST['btneditar'])){

    $id = $_POST['recipient_id'];
    $nombrenuevo = $_POST['recipient_nombre'];
    $apellidonuevo = $_POST['recipient_apellido'];
    $curpnuevo = $_POST['recipient_curp'];


    $conexion->query("UPDATE pacientes_reservados SET Nombre = '$nombrenuevo', Apellido= '$apellidonuevo',Curp='$curpnuevo' WHERE idUsuarios= $id AND NombreEspecialista = '$tallerista_seleccionado' AND 
    NombreEspecialidad = '$taller_seleccionado' AND Calendario = '$calendario_seleccionado' AND 
    Hora = '$hora_seleccionado'");

//$result_update = mysqli_query($conexion,$update_usuario);

if($conexion){
    echo "<script type='text/javascript'>
    window.location='citas1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&hora=$hora_seleccionado'
    </script>";
}else{
    echo '<script>alertaeNoti("No se pudo actualizar la informacion")</script>';
}
    
    //header("Refresh:1");
         
        }

?>



</div>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</body>
</html>
<?php  $conexion=null; ?>